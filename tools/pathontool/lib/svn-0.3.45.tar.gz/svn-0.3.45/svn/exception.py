class SvnException(Exception):
    """
    Raised when the SVN CLI command returns an error code.
    """

    pass
