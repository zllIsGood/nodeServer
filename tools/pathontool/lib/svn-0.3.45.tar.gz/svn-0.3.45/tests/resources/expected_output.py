__author__ = 'tusharmakkar08'

diff_summary = [{'item': 'modified',
                 'kind': 'file',
                 'path': 'http://svn.apache.org/repos/asf/sling/trunk/pom.xml'},
                {'item': 'added',
                 'kind': 'file',
                 'path': 'http://svn.apache.org/repos/asf/sling/trunk/bundles/extensions/models/pom.xml'}]
diff_summary_2 = [{'item': 'added',
                   'kind': 'file',
                   'path': 'http://svn.apache.org/repos/asf/sling/trunk/bundles/extensions/models/pom.xml'},
                  {'item': 'modified',
                   'kind': 'file',
                   'path': 'http://svn.apache.org/repos/asf/sling/trunk/pom.xml'}
                  ]
cat = """This is an as-yet incomplete update for Abdera. All of the base dependencies
have been updated and a broad range of significant changes have been made to
the overall code structure, many of the apis and implementation detail. """
